exports.handler = async () => {
  console.log("Lambda placeholder executed");
  return { status: "ok" };
};
